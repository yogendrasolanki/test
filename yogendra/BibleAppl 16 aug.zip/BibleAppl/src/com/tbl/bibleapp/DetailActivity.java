package com.tbl.bibleapp;

import java.io.IOException;
import java.io.InputStream;

import android.app.ActionBar;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class DetailActivity extends Activity {

private LayoutInflater lflater;
private ProgressDialog mProgressDialog;
private String displayText = "";
private Context appContext;
private Typeface mFace;
	
int requestFor;
	String[] textEntries ;
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

	    setContentView(R.layout.right_fragment_list);
	    appContext = this;
	    mFace = Typeface.createFromAsset(getApplicationContext().getAssets(),"fonts/SLC.ttf");
	    
	    Bundle bundle = getIntent().getExtras();
	    requestFor = bundle.getInt("requestFor");
	    
	    
	    ActionBar bar =getActionBar();
	    
	    if(requestFor==Constant.RELATIONSHIP){
	    	bar.setTitle("Relationships and Sex");	    	 
	    }else if(requestFor==Constant.HEALTH){
	    	bar.setTitle("Health and Your Body");
		}else if(requestFor==Constant.MONEY){
			bar.setTitle("Money and Work");
		}else if(requestFor==Constant.FEELINGS){
			bar.setTitle("Feelings and Emotions");
		}else if(requestFor==Constant.GOD){
			bar.setTitle("God");
		}else if(requestFor==Constant.SETUP){
			bar.setTitle("Setup and Info");
		}
	    
	    if(requestFor==7)
	    {
	    	
	    	Intent intent = new Intent(appContext, TestActivity.class);
	    	startActivity(intent);
	    }
	    
		
		if(requestFor!=6 && requestFor!=7)
	    {
	    new GetTopics().execute();
	    }
	    else
	    {
	    	  lflater = (LayoutInflater) getApplicationContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
	    	  LinearLayout ll = (LinearLayout) findViewById(R.id.layoutOption);
				for (int i = 0; i < Constant.SETUPNINFO.length; i++) {
					// System.out.println(textEntries[i]);
					final LinearLayout holder = (LinearLayout) lflater.inflate(
							R.layout.cell_layout, null);
					TextView txtTitle = (TextView) holder.findViewById(R.id.txtTitle);
					holder.setTag(i);
					txtTitle.setText(Constant.SETUPNINFO[i]);
					txtTitle.setTypeface(mFace);
					if (i == (Constant.SETUPNINFO.length - 1)) {
						((LinearLayout) holder.findViewById(R.id.cell_seprator))
								.setVisibility(View.GONE);
					}
					
					ll.addView(holder);
					holder.setOnClickListener(new View.OnClickListener() {

						@Override
						public void onClick(View v) {
							// TODO Auto-generated method stub
						if (holder.getTag().toString().equals("0")) {
							Intent intent = new Intent(Intent.ACTION_VIEW);
							intent.setData(Uri
									.parse("market://details?id=com.PandoraTV"));
							if (MyStartActivity(intent) == false) {
								// Market (Google play) app seems not installed,
								// let's try to open a webbrowser
								intent.setData(Uri
										.parse("https://play.google.com/store/apps/details?id=com.PandoraTV"));
							
							}
						}
						else
						{
							Intent intent = new Intent(appContext, SetupDetailActivity.class);
							intent.putExtra("TAG", holder.getTag().toString());
							startActivity(intent);
						}
					}
				});

			}
			 
	    }
	  
	
	   
	 	}
	
	public class GetTopics extends AsyncTask<Void, Void, String>
	{
		

		@Override
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();
			mProgressDialog = ProgressDialog.show(appContext, "Please wait", "Loading...");
			mProgressDialog.setCancelable(true);
		}

		@Override
		protected String doInBackground(Void... params) {
			// TODO Auto-generated method stub
			   lflater = (LayoutInflater) getApplicationContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
				  
	    		try {
	    			InputStream fileStream = null;
	    		if(requestFor==Constant.RELATIONSHIP)
	    		{
	    			fileStream = getResources().openRawResource(R.raw.relationships);
	    		}
	    		if(requestFor==Constant.HEALTH)
	    		{
	    			fileStream = getResources().openRawResource(R.raw.health);
	    		}
	    		if(requestFor==Constant.MONEY)
	    		{
	    			fileStream = getResources().openRawResource(R.raw.money);
	    		}
	    		if(requestFor==Constant.FEELINGS)
	    		{
	    			fileStream = getResources().openRawResource(R.raw.feelings);
	    		}
	    		int fileLen = fileStream.available();
	    		// Read the entire resource into a local byte buffer.
	    		byte[] fileBuffer = new byte[fileLen];
	    		fileStream.read(fileBuffer);
	    		fileStream.close();
	    		displayText = new String(fileBuffer);
	    		} catch (IOException e) {
	    		  // exception handling
	    		}
	    		
	    		String[] tabOfShortString = displayText.split("\n");
	    	    int length = tabOfShortString.length;
	    	    System.out.println("Length of float string is" + length);
	    	    textEntries = new String[length];
	    	    for (int l = 0; l < length; l++) {
	    	        String res = new String(tabOfShortString[l]);
	    	        textEntries[l] = res;
	    	    }
	    	
		
			
			return null;
		}

		@Override
		protected void onPostExecute(String result) {
			
			  LinearLayout ll = (LinearLayout) findViewById(R.id.layoutOption);
			  //ll.setBackgroundResource(R.drawable.corner_style);
				for (int i = 0; i < textEntries.length; i++) {
					// System.out.println(textEntries[i]);
					final LinearLayout holder = (LinearLayout) lflater.inflate(
							R.layout.cell_layout, null);
					TextView txtTitle = (TextView) holder.findViewById(R.id.txtTitle);
					holder.setTag(textEntries[i]);
					//holder.setBackgroundResource(R.drawable.corner_style);
					txtTitle.setText(textEntries[i]);
					txtTitle.setTypeface(mFace);
					if (i == (textEntries.length - 1)) {
						((LinearLayout) holder.findViewById(R.id.cell_seprator))
								.setVisibility(View.GONE);
					}
					
					ll.addView(holder);
					holder.setOnClickListener(new View.OnClickListener() {

						@Override
						public void onClick(View v) {
							// TODO Auto-generated method stub

							if (requestFor == Constant.RELATIONSHIP) {
								Toast.makeText(getApplicationContext(),
										"relations :" + holder.getTag().toString(),
										Toast.LENGTH_SHORT).show();
							}
							if (requestFor == Constant.HEALTH) {
								Toast.makeText(getApplicationContext(),
										"health :" + holder.getTag().toString(),
										Toast.LENGTH_SHORT).show();
							}
							if (requestFor == Constant.MONEY) {
								Toast.makeText(getApplicationContext(),
										"money :" + holder.getTag().toString(),
										Toast.LENGTH_SHORT).show();
							}
							if (requestFor == Constant.FEELINGS) {
								Toast.makeText(getApplicationContext(),
										"feelings :" + holder.getTag().toString(),
										Toast.LENGTH_SHORT).show();
							}
						}
					});

				}		

			// TODO Auto-generated method stub
			if(mProgressDialog!=null)
			{
				mProgressDialog.dismiss();
			}
		}		
	}
	
	private boolean MyStartActivity(Intent aIntent) {
		try{
			startActivity(aIntent);
			return true;
		}
		catch (ActivityNotFoundException e){
			return false;
		}
	}
}

