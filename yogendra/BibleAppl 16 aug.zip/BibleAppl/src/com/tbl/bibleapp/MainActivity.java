package com.tbl.bibleapp;


import android.app.ActionBar;
import android.app.Activity;
import android.app.Fragment;
import android.app.FragmentTransaction;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Resources;
import android.os.Bundle;
import android.support.v4.content.LocalBroadcastManager;
import android.util.TypedValue;
import android.widget.LinearLayout;

public class MainActivity extends Activity{
	int requestFor = 2;
	String pane;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);		
		boolean tabletSize = getResources().getBoolean(R.bool.isTablet);
		System.out.println("TAB"+tabletSize);
		if (tabletSize) {
			setContentView(R.layout.activity_main);
			
			LinearLayout layoutLeftPane = (LinearLayout) findViewById(R.id.layoutLeftPane);
			Resources r = getResources();
			int width = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 320, r.getDisplayMetrics());
			int heifht = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, layoutLeftPane.getLayoutParams().height, r.getDisplayMetrics());
			ActionBar bar= getActionBar();
			bar.setTitle("Bible App");
			layoutLeftPane.setLayoutParams(new LinearLayout.LayoutParams(width, heifht));
			
			System.out.println("1");
		} else {
			setContentView(R.layout.activity_main_small);
			System.out.println("0");
			ActionBar bar= getActionBar();
			bar.setTitle("Bible App");
		}
		
		//Local broad cast manager 
		LocalBroadcastManager.getInstance(getApplicationContext()).registerReceiver(mBraoadCaseMesagner,new IntentFilter("ClickLoadPage"));
	}
	public BroadcastReceiver mBraoadCaseMesagner = new BroadcastReceiver() {
		@Override
		public void onReceive(Context context, Intent intent) {
			// TODO Auto-generated method stub
			Bundle bundle = intent.getExtras();
			requestFor = bundle.getInt("requestFor");
			pane = bundle.getString("PANE");
			onRssItemSelected(requestFor, pane);
			
		}
	};
	
	public void onRssItemSelected(int requestFor,String link) 
	{
		// TODO Auto-generated method stub
		RightFragment fragment = (RightFragment) getFragmentManager()
	            .findFragmentById(R.id.right_fragment);

	        if (fragment != null && fragment.isInLayout())
	        {
	        	if(link.equals("left"))
	        	{
	        		
	        	System.out.println("In If-left pane");
	        	Utility.setSharedPreference(getApplicationContext(), "Pref",requestFor);
	        	System.out.println(requestFor);
	        	fragment.setOptionData(requestFor);
	        	}
	        	if(link.equals("right"))
	        	{
	        		Fragment newFragment = new OptionsFragment();
		        	 Bundle bundle = new Bundle();
		        	 bundle.putInt("requestFor",requestFor); //any string to be sent
		        	 newFragment.setArguments(bundle);
		        	FragmentTransaction transaction = getFragmentManager().beginTransaction();
		        	transaction.replace(R.id.layoutRightPane, newFragment);
		        	transaction.addToBackStack(null);
		        	transaction.commit();

	        	}
	        	
	        	//FragmentTransaction transaction = getFragmentManager().beginTransaction();
	        	//transaction.replace(R.id.layoutRightPane, newFragment);	        	
	        	//transaction.commit();
	        } 
	        else 
	        { 
	        	  System.out.println("IN ELSE");	        	  
	        	  Intent intent = new Intent(getApplicationContext(), DetailActivity.class);
	        	  intent.putExtra("requestFor", requestFor);
	        	  startActivity(intent);              
            }
	}
}

	
	


