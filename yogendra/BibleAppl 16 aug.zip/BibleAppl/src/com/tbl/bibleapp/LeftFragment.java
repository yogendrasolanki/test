package com.tbl.bibleapp;



import android.app.Fragment;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.v4.content.LocalBroadcastManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

public class LeftFragment extends Fragment{
	
	private Typeface mFace;
	  
	 
	  
	  @Override
	  public View onCreateView(LayoutInflater inflater, ViewGroup container,
	      Bundle savedInstanceState) {
	    final View view = inflater.inflate(R.layout.fragment_left_pane,
	        container, false);
	    
	    mFace = Typeface.createFromAsset(getActivity().getAssets(),"fonts/SLC.ttf");
	    
	   LinearLayout ll_health = (LinearLayout) view.findViewById(R.id.layoutHealthYourBody);
	   LinearLayout ll_relationship = (LinearLayout) view.findViewById(R.id.layoutRelationAndS);
	   LinearLayout ll_money = (LinearLayout) view.findViewById(R.id.layoutMoneyAndWork);
	   LinearLayout ll_feelings = (LinearLayout) view.findViewById(R.id.layoutFeelingsAndEmotions);
	   LinearLayout ll_keywords = (LinearLayout) view.findViewById(R.id.layoutKeywordsAndPhrase);
	   LinearLayout ll_bible = (LinearLayout) view.findViewById(R.id.layoutBible);
	   LinearLayout ll_setup = (LinearLayout) view.findViewById(R.id.layoutSetupAndInfo);
	   
	   TextView tv_health = (TextView) view.findViewById(R.id.textVhealth);
	   TextView tv_relationship = (TextView) view.findViewById(R.id.textVrelation);
	   TextView tv_money = (TextView) view.findViewById(R.id.textVMoney);
	   TextView tv_feelings = (TextView) view.findViewById(R.id.textVfeelings);
	   TextView tv_keywords = (TextView) view.findViewById(R.id.textVkeywords);
	   TextView tv_bible = (TextView) view.findViewById(R.id.txtVbible);
	   TextView tv_setup = (TextView) view.findViewById(R.id.txtVsetup);
	   
	   tv_health.setTypeface(mFace);
	   tv_relationship.setTypeface(mFace);
	   tv_money.setTypeface(mFace);
	   tv_feelings.setTypeface(mFace);
	   tv_keywords.setTypeface(mFace);
	   tv_bible.setTypeface(mFace);
	   tv_setup.setTypeface(mFace);
	   
	 
	   ll_health.setOnClickListener(onclickListener);
	   ll_relationship.setOnClickListener(onclickListener);
	   ll_money.setOnClickListener(onclickListener);
	   ll_feelings.setOnClickListener(onclickListener);
	   ll_keywords.setOnClickListener(onclickListener);
	   ll_bible.setOnClickListener(onclickListener);
	   ll_setup.setOnClickListener(onclickListener);
	 /*   ll.setOnClickListener(new View.OnClickListener() {
	      @Override
	      public void onClick(View v) {
	        updateDetail();
	      }
	    });*/
	    
	    return view;
	  }
	  
	  OnClickListener onclickListener = new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				
				int id = v.getId();
				Intent intent;
				switch(id){
				case R.id.layoutHealthYourBody:
					 intent = new Intent("ClickLoadPage");
					  intent.putExtra("requestFor", Constant.HEALTH);
					  intent.putExtra("PANE", "left");
					  intent.putExtra("HEADING", "Health And Your Body ");
					  LocalBroadcastManager.getInstance(getActivity()).sendBroadcast(intent);
					break;
					
				case R.id.layoutRelationAndS:
					TextView txtVrelation = (TextView)v.findViewById(R.id.textVrelation);
					//String relation = txtVrelation.getText().toString();
					 intent = new Intent("ClickLoadPage");
					  intent.putExtra("requestFor", Constant.RELATIONSHIP);
					  intent.putExtra("HEADING", "Relationship and Sex");
					  intent.putExtra("PANE", "left");
					 
					  
					 LocalBroadcastManager.getInstance(getActivity()).sendBroadcast(intent);
					break;
					
				case R.id.layoutMoneyAndWork:
					 intent = new Intent("ClickLoadPage");
					  intent.putExtra("requestFor", Constant.MONEY);
					  intent.putExtra("PANE", "left");
					  intent.putExtra("HEADING", "Money And Work");
					  LocalBroadcastManager.getInstance(getActivity()).sendBroadcast(intent);
					break;
					
				case R.id.layoutFeelingsAndEmotions:
					 intent = new Intent("ClickLoadPage");
					  intent.putExtra("requestFor", Constant.FEELINGS);
					  intent.putExtra("PANE", "left");
					  intent.putExtra("HEADING", "Feelings And Emotions");
					  LocalBroadcastManager.getInstance(getActivity()).sendBroadcast(intent);
					break;
					
				case R.id.layoutKeywordsAndPhrase:
					TextView txtVkeywords = (TextView)v.findViewById(R.id.textVkeywords);
					//String keywords = txtVkeywords.getText().toString();
					updateDetail("keywords");
					break;
					
				case R.id.layoutBible:
					 intent = new Intent("ClickLoadPage");
					  intent.putExtra("requestFor", Constant.BIBLE);
					  intent.putExtra("PANE", "left");
					  intent.putExtra("HEADING", "bible");
					  LocalBroadcastManager.getInstance(getActivity()).sendBroadcast(intent);
					break;
					
				case R.id.layoutSetupAndInfo:
					 intent = new Intent("ClickLoadPage");
					  intent.putExtra("requestFor", Constant.SETUP);
					  intent.putExtra("PANE", "left");
					  LocalBroadcastManager.getInstance(getActivity()).sendBroadcast(intent);
					break;
					
				}
				
			}
		};

	  // May also be triggered from the Activity
	  public void updateDetail(String heading) {
	    // Create fake data
	  //  String newTime = String.valueOf(System.currentTimeMillis());
	    // Send data to Activity
	    //listener.onRssItemSelected(heading);
		 
	  }
	} 