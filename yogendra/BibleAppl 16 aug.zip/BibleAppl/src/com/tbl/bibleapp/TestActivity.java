package com.tbl.bibleapp;

import java.io.IOException;
import java.io.InputStream;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

public class TestActivity extends Activity
{
	private Context appContext;
	private LayoutInflater lflater;
	private String xml = "";
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

	    setContentView(R.layout.test);
	    appContext = this;
	    
	    InputStream stream = getResources().openRawResource(R.raw.ghi);
	    try {
	        byte[] buffer = new byte[stream.available()];
	        stream.read(buffer);        
	        stream.close();
	        xml = new String(buffer, "UTF-8"); 
	        System.out.println("String"+xml);
	        // you just need to specify the charsetName   
	    } catch (IOException e) {
	        // Error handling
	    }
	 //   lflater = (LayoutInflater) getApplicationContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
	    
	   /* try {
			InputStream fileStream = getResources().openRawResource(R.raw.chapter);
		
		
	
		int fileLen = fileStream.available();
		// Read the entire resource into a local byte buffer.
		byte[] fileBuffer = new byte[fileLen];
		fileStream.read(fileBuffer);
		fileStream.close();
		displayText = new String(fileBuffer);
		} catch (IOException e) {
		  // exception handling
		}*/
	    
	  
  	 TextView txtV_test = (TextView)findViewById(R.id.txtV_test);
  	 txtV_test.setText(xml);
	    
	}

}
