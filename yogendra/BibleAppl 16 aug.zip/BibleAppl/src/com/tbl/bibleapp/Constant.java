package com.tbl.bibleapp;

public class Constant {
	//Pages 
	public static final int RELATIONSHIP=1;
	public static final int HEALTH=2;
	public static final int MONEY=3;
	public static final int FEELINGS=4;
	public static final int GOD=5;
	public static final int SETUP=6;
	public static final int BIBLE=7;
	public static final String[] SETUPNINFO = new String[]{"Post Review","Bible Version","Webpage","Feedback to developer","About"};
	public static final String[] BIBLEVERSION = new String[]{"Web","King James Bible"};
}
