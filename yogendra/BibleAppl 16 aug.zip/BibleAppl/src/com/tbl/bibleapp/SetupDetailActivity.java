package com.tbl.bibleapp;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

public class SetupDetailActivity extends Activity {
	
	private Context appContext;
	private LayoutInflater lflater;
	private Typeface mFace;
	
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

	    setContentView(R.layout.right_fragment_list);
	    appContext = this;
	    
	    mFace = Typeface.createFromAsset(getApplicationContext().getAssets(),"fonts/SLC.ttf");
	    String tag;
	    Bundle bundle = getIntent().getExtras();
	    tag = bundle.getString("TAG");
	    
	    //bible version
	    if(tag.equals("1"))
	    {
	    	lflater = (LayoutInflater) getApplicationContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
	    	  LinearLayout ll = (LinearLayout) findViewById(R.id.layoutOption);
				for (int i = 0; i < Constant.BIBLEVERSION.length; i++) {
					// System.out.println(textEntries[i]);
					final LinearLayout holder = (LinearLayout) lflater.inflate(
							R.layout.cell_layout, null);
					TextView txtTitle = (TextView) holder.findViewById(R.id.txtTitle);
					holder.setTag(i);
					txtTitle.setText(Constant.BIBLEVERSION[i]);
					txtTitle.setTypeface(mFace);
					if (i == (Constant.BIBLEVERSION.length - 1)) {
						((LinearLayout) holder.findViewById(R.id.cell_seprator))
								.setVisibility(View.GONE);
					}
					
					ll.addView(holder);
					holder.setOnClickListener(new View.OnClickListener() {

						@Override
						public void onClick(View v) {
							// TODO Auto-generated method stub
						
					}
				});
	    }
	}

}
}
