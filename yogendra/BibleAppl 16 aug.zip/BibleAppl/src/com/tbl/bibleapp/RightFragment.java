package com.tbl.bibleapp;

import java.io.IOException;
import java.io.InputStream;

import android.app.Fragment;
import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.content.LocalBroadcastManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class RightFragment extends Fragment {
	String[] textEntries ;
	int requestFor = 0;
    String displayText = "";
    View mainview;
	private LayoutInflater lflater;
	private Typeface mFace;
	  @Override
	  public View onCreateView(LayoutInflater inflater, ViewGroup container,
	      Bundle savedInstanceState) {
		mainview = inflater.inflate(R.layout.right_fragment_list,
	        container, false);
		
		  mFace = Typeface.createFromAsset(getActivity().getAssets(),"fonts/SLC.ttf");
	    
	    if (requestFor !=0)
    	{   
	    requestFor = Utility.getSharedPreferences1(getActivity(), "Pref");
    	}   
	   	  
	    lflater = (LayoutInflater) getActivity().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
	   
	    setOptionData(requestFor);
	   
	   
	    return mainview;
	 	}
	  
	  
	  
	  public void setOptionData(int request)
	  {
		  System.out.println(request);
		  
		  if (requestFor == 0){
			    requestFor = Constant.HEALTH;
		  }else if (requestFor==request) {
				System.out.println(requestFor);
			return;
		  }
		  else
		  {
		  requestFor = request;
		  }
		  
		  
		  if(requestFor!=6 && requestFor!=7)
		  {
			  
		  try {
				InputStream fileStream = null;
				System.out.println("REq"+requestFor);
			if(requestFor==Constant.RELATIONSHIP)
			{
				fileStream = getResources().openRawResource(R.raw.relationships);
			}
			if(requestFor==Constant.HEALTH)
			{
				fileStream = getResources().openRawResource(R.raw.health);
			}
			if(requestFor==Constant.MONEY)
			{
				fileStream = getResources().openRawResource(R.raw.money);
			}
			if(requestFor==Constant.FEELINGS)
			{
				fileStream = getResources().openRawResource(R.raw.feelings);
			}
			if(requestFor==Constant.BIBLE)
			{
				fileStream = getResources().openRawResource(R.raw.chapter);
			}
			System.out.println("File"+fileStream );
			int fileLen = fileStream.available();
			// Read the entire resource into a local byte buffer.
			byte[] fileBuffer = new byte[fileLen];
			fileStream.read(fileBuffer);
			fileStream.close();
			displayText = new String(fileBuffer);
			} catch (IOException e) {
			  // exception handling
			}
			
			String[] tabOfShortString = displayText.split("\n");
		    int length = tabOfShortString.length;
		    System.out.println("Length of float string is" + length);
		    textEntries = new String[length];
		    for (int l = 0; l < length; l++) {		        
		        String res = new String(tabOfShortString[l]);		       
		        textEntries[l] = res;		      
		    }
		    LinearLayout ll = (LinearLayout)mainview.findViewById(R.id.layoutOption);
		    ll.removeAllViews();
		    for ( int i = 0; i < textEntries.length; i++)
		 	{	
		    	//System.out.println(textEntries[i]);
		    	final LinearLayout holder = (LinearLayout) lflater.inflate(R.layout.cell_layout, null);
		 	    TextView txtTitle = (TextView) holder.findViewById(R.id.txtTitle);
		 	    holder.setTag(textEntries[i]);
		 	    txtTitle.setText(textEntries[i]);
		 	    txtTitle.setTypeface(mFace);
		 	    if (i== (textEntries.length -1)) {
					((LinearLayout)holder.findViewById(R.id.cell_seprator)).setVisibility(View.GONE);
				}
		        ll.addView(holder);
		        holder.setOnClickListener(new View.OnClickListener() {
					
					@Override
					public void onClick(View v) {
						// TODO Auto-generated method stub
						
						if (requestFor == Constant.RELATIONSHIP) {
							Toast.makeText(getActivity(),"relations :"+holder.getTag().toString(), Toast.LENGTH_SHORT).show();
						}
						if (requestFor == Constant.HEALTH) {
							Toast.makeText(getActivity(),"health :"+holder.getTag().toString(), Toast.LENGTH_SHORT).show();
						}
						if (requestFor == Constant.MONEY) {
							Toast.makeText(getActivity(),"money :"+holder.getTag().toString(), Toast.LENGTH_SHORT).show();
						}
						if (requestFor == Constant.FEELINGS) {
							Toast.makeText(getActivity(),"feelings :"+holder.getTag().toString(), Toast.LENGTH_SHORT).show();
						}
					}
			});		       
	 	}
		  }//if ends
		  
		  //if request not for health,relation,feelings,money
		  else if(requestFor!=7)
		  {
			  System.out.println("REQFOR"+requestFor);
			  lflater = (LayoutInflater) getActivity().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
	    	  LinearLayout ll = (LinearLayout) mainview.findViewById(R.id.layoutOption);
	    	  ll.removeAllViews();
				for (int i = 0; i < Constant.SETUPNINFO.length; i++) {
					// System.out.println(textEntries[i]);
					final LinearLayout holder = (LinearLayout) lflater.inflate(
							R.layout.cell_layout, null);
					TextView txtTitle = (TextView) holder.findViewById(R.id.txtTitle);
					holder.setTag(i);
					txtTitle.setText(Constant.SETUPNINFO[i]);
					txtTitle.setTypeface(mFace);
					if (i == (Constant.SETUPNINFO.length - 1)) {
						((LinearLayout) holder.findViewById(R.id.cell_seprator))
								.setVisibility(View.GONE);
					}
					
					ll.addView(holder);
					holder.setOnClickListener(new View.OnClickListener() {

						@Override
						public void onClick(View v) {
							// TODO Auto-generated method stub
						
							Intent intent = new Intent("ClickLoadPage");
							int set = Integer.parseInt(holder.getTag().toString());
							  intent.putExtra("requestFor", set);
							  intent.putExtra("PANE", "right");
							  LocalBroadcastManager.getInstance(getActivity()).sendBroadcast(intent);
					}
				});

			}
			 
		  }
		 
 	}
}