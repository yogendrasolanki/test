/** Automatically generated file. DO NOT MODIFY */
package com.tbl.bibleapp;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}